//
//  UserManager.swift
//  AITherapist
//
//  Created by cyrus refahi on 1/1/24.
//

import Foundation

//class UserManager: ObservableObject {
//    //Singleton
//    static let shared = UserManager()
//    @Published var user: Loadable<User> = .notRequested
//    
//    func logout() {
//        self.user = .notRequested
//    }
//}
