//
//  Fonts.swift
//  AITherapist
//
//  Created by Cyrus Refahi on 10/1/23.
//

import Foundation
import SwiftUI

// color: #D9D9D9;
// font-family: Inter;
// font-size: 12px;
// font-style: normal;
// font-weight: 500;
// line-height: normal;

let helpLineFont = Font.custom("Inter", size: 12)
